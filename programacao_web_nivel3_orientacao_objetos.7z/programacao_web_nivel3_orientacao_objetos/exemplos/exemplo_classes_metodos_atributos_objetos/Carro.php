<?php 

class Carro{

    private string $modelo = "Fusca";
    private int    $velocidade = 0;
    private float  $preco = 10500;
    private float  $multa = 0;

    public function informar_velocidade()
    {
        return $this->velocidade;
    }

    public function aplicar_multa($multa)
    {
        $this->multa = $multa;
    }

    public function informa_extrato_multa()
    {
        if ($this->multa > 0)
        {
            return $this->multa;
        } 
        else 
        {
            return "O carro não possui pendência no DETRAN";
        }
    }
    
    public function acelerar($velocidade)
    {
        return $this->velocidade = $velocidade;
    }

    public function frear($velocidade)
    {
        return $this->velocidade = $velocidade;
    }
    
}