<?php 

require_once("Carro.php");

$carro = new Carro();
echo "Fusca Ascelerando ...".$carro->acelerar(140);
echo "<hr>";
echo "Fusca Freando ...".$carro->frear(0);

if ($carro->informar_velocidade() >= 140)
{
    $carro->aplicar_multa(350.25);
}

echo "<hr>";
echo "Extrato de multa ...".$carro->informa_extrato_multa(0);