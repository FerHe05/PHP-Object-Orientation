<?php 

require_once("Conta.php");

$conta = new Conta();
$conta->saque(100);

echo $conta->getSaldo();