<?php 

class Conta{
    private float $saldo = 100000;
    
    public function saque($valor)
    {
        $this->saldo -= $valor;
        $taxa_saque = ($valor * 2) /100;
        $this->saldo -= $taxa_saque;
    }
    
    public function getSaldo()
    {
        return $this->saldo;
    }
  
    
} 