<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="objeto.php" method="post">
        <table align="center" border="2">
            <tr>
                <td>Nome></td>
                <td><input type="text" name="nome" id=""></td>
            </tr>
            <tr>
                <td>CPF</td>
                <td><input type="text" name="cpf" id=""></td>
            </tr>
            <tr>
                <td>Dependentes></td>
                <td><input type="number" name="numero_dependentes" id=""></td>
            </tr>
            <tr>
                <td>Vale Transporte</td>
                <td>
                    <select name="vale_transporte" id="">
                        <option value="">Selecionar</option>
                        <option value="sim">Sim</option>
                        <option value="nao">Não</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Salário Bruto</td>
                <td><input type="text" name="salario_bruto" id=""></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="enviar" value="Enviar"></td>
            </tr>
        </table>
    </form>
</body>
</html>