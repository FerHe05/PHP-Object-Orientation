<?php 

if (isset($_POST["enviar"]))
{
    require_once("Funcionario.php");

    $dados_form = new stdClass();
    $dados_form->nome = $_POST["nome"];
    $dados_form->cpf = $_POST["cpf"];
    $dados_form->numero_dependentes = $_POST["numero_dependentes"];
    $dados_form->vale_transporte = $_POST["vale_transporte"];
    $dados_form->salario_bruto = $_POST["salario_bruto"];
   
    $funcionario = new Funcionario();

    if ($funcionario->valida_form($dados_form))
    {
        $funcionario->atribuir_dados_form($dados_form);

        $funcionario->calcular_fgts();

        $funcionario->calcular_salario_familia();

        $funcionario->calcular_vale_transporte();

        $funcionario->calcular_inss();

        var_dump( $funcionario);
    }
    else 
    {
        echo "Preencha todos os campos do formulário";
    }
}