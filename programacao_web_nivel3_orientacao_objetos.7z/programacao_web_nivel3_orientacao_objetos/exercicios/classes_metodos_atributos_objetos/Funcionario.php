<?php 

class Funcionario{

    private string $nome;
    private string $cpf;
    private string $numero_dependentes;
    private string $vale_transporte;
    private string $salario_bruto;
    
    private string $fgts;
    private string $desconto_inss;
    private string $salario_descontado_inss;
    private string $descontado_imposto_renda;
    private string $salario_familia;
    private string $descontado_vale_transporte;
    private string $salario_liquido;  


    public function valida_form($dados_form)
    {
        if (
            ($dados_form->nome == "") ||
            ($dados_form->cpf == "") ||
            ($dados_form->numero_dependentes == "") ||
            ($dados_form->numero_dependentes < 0) ||
            ($dados_form->vale_transporte == "") ||
            ($dados_form->salario_bruto == "") 
        
        )
        {
            return false;
        }
        else 
        {
            return true;
        }
    }

    public function atribuir_dados_form($dados_form)
    {
        $this->nome = $dados_form->nome;
        $this->cpf = $dados_form->cpf;
        $this->numero_dependentes = $dados_form->numero_dependentes;
        $this->vale_transporte = $dados_form->vale_transporte;
        $this->salario_bruto = $dados_form->salario_bruto;        
    }

    public function calcular_fgts()
    {
        $this->fgts = ($this->salario_bruto * 8) /100;
    }

    public function calcular_salario_familia()
    {
        if ($this->salario_bruto <= 1754.18)
        {
            $this->salario_familia = $this->numero_dependentes * 59.82;
        }
        else 
        {
            $this->salario_familia = 0;
        }
    }

    public function calcular_vale_transporte()
    {
        if ($this->vale_transporte == "sim")
        {
            $this->descontado_vale_transporte = ($this->salario_bruto * 6) / 100;
        }
        else 
        {
            $this->descontado_vale_transporte = 0;
        }
    }

    public function calcular_inss()
    {
        if ($this->salario_bruto <= 1302)
        {
            $this->desconto_inss = ($this->salario_bruto * 7.5) /100;
        }
        else if (($this->salario_bruto > 1302) && ($this->salario_bruto <= 2571.29))
        {
            $primeira_faixa = (1302 * 7.5) /100;

            $diferenca_segunda_faixa = $this->salario_bruto - 1302;

            $segunda_faixa = ($diferenca_segunda_faixa * 9) /100;

            $this->desconto_inss = $primeira_faixa + $segunda_faixa;            
        }
        else if (($this->salario_bruto > 2571.29) && ($this->salario_bruto <= 3856.94))
        {
            $primeira_faixa = (1302 * 7.5) /100;
            $diferenca_segunda_primeira_faixa = 2571.29 - 1302;

            $segunda_faixa = ($diferenca_segunda_primeira_faixa * 9)/ 100;
        
            $diferenca_terceira_faixa = $this->salario_bruto - 2571.29;
            $terceira_faixa = ($diferenca_terceira_faixa * 12)/100;

            $this->desconto_inss = $primeira_faixa + $segunda_faixa +  $terceira_faixa;
            $this->desconto_inss = number_format($this->desconto_inss, 2);
        
        }  
        else if (($this->salario_bruto > 3856.94) && ($this->salario_bruto <= 7507.49))
        {
            $primeira_faixa = (1302 * 7.5) /100;
            $diferenca_segunda_primeira_faixa = 2571.29 - 1302;

            $segunda_faixa = ($diferenca_segunda_primeira_faixa * 9)/ 100;
            
            $diferenca_terceira_segunda_faixa = 3856.94 - 2571.29;
            $terceira_faixa = ( $diferenca_terceira_segunda_faixa * 12)/ 100;

            $diferenca_quarta_faixa = $this->salario_bruto - 3856.94;

            $quarta_faixa = ( $diferenca_quarta_faixa * 14) /100;
        
            $this->desconto_inss = $primeira_faixa + $segunda_faixa +  $terceira_faixa + $quarta_faixa;
            $this->desconto_inss = number_format($this->desconto_inss, 2);
        } 
        else if($this->salario_bruto > 7507.49)
        {
            $this->desconto_inss = 877.25;
        } 
        
        $this->salario_descontado_inss = $this->salario_bruto - $this->desconto_inss;
    }
}