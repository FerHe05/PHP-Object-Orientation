<?php 
include_once("../cabecalho.php");
include_once("../menu.php");
require_once("../Sessao.php");
?>

<table class="table table-dark">
    <thead>
        <tr>
            <th scope="col">Id</th>
            <th scope="col">Modelo</th>
            <th scope="col">Preco</th>                    
        </tr>
    </thead>
<tbody>
    <?php

    $session = new Sessao();
    $session->inicia_sessao();
    
    if (isset($_SESSION["veiculos"]))
    {
        foreach ($_SESSION["veiculos"] as $key => $veiculo) 
        {
            echo '
            <tr>
                <th>'.$key.'</th>
                <th>'.$veiculo["modelo"].'</th>
                <td>'.$veiculo["preco"].'</td>   
            </tr>';    
        } 
    }
    

echo '</tbody>
</table>';