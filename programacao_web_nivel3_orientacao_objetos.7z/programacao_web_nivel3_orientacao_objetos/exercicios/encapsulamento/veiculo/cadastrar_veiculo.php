<?php 
include_once("../menu.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        <table align="center" border="2">            
            <tr>
                <td>Veiculo</td>
                <td><input type="text" name="modelo"></td>
            </tr>
            <tr>
                <td>Preço</td>
                <td><input type="text" name="preco"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="cadastrar"></td>
            </tr>
        </table>
    </form>
</body>
</html>

<?php 

require_once("VeiculosDisponiveis.php");

if (isset($_POST["cadastrar"]))
{
    $veiculosDisponiveis = new VeiculosDisponiveis();
    $dados_form = new stdClass();
    $dados_form->modelo = $_POST["modelo"];
    $dados_form->preco = $_POST["preco"];
    
    if ($veiculosDisponiveis->valida_dados_veiculo($dados_form))
    {        
        $veiculosDisponiveis->insereVeiculo($dados_form);
    }
    else 
    {
        echo "Preencha os dados Corretamente";
    }   
}