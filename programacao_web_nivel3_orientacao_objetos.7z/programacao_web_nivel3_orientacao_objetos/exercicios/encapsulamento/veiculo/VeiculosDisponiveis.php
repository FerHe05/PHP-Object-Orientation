<?php

require_once("../Sessao.php");

class VeiculosDisponiveis{

    public function valida_dados_veiculo($dados_form)
    {
        if (
            ($dados_form->modelo == "") || 
            ($dados_form->preco == "") || 
            ($dados_form->preco <= 0) 
        ) 
        {
            return false;
        }
        else 
        {
            return true;
        }
    }

    public function insereVeiculo($dados_form)
    {
        $session = new Sessao();
        $session->inicia_sessao();
        $session->inicia_session_contadorVeiculos();

        $_SESSION["veiculos"][$_SESSION["contadorVeiculo"]]["modelo"] = $dados_form->modelo;
        $_SESSION["veiculos"][$_SESSION["contadorVeiculo"]]["preco"]  = $dados_form->preco;
    }

}