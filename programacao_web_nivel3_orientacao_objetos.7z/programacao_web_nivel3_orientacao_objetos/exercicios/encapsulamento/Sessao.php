<?php 

class Sessao{
    public function inicia_sessao()
    {
        if (session_status() != PHP_SESSION_ACTIVE) 
        {
            session_start();
        }        
    }

    public function inicia_session_contadorFinanciadoras()
    {
        $this->inicia_sessao();

        if (!isset($_SESSION["contadorFinanciadora"]))
        {
            $_SESSION["contadorFinanciadora"] = 0;
        }
        else 
        {
            $_SESSION["contadorFinanciadora"]++;
        }
    }

    public function inicia_session_contadorVeiculos()
    {
        $this->inicia_sessao();

        if (!isset($_SESSION["contadorVeiculo"]))
        {
            $_SESSION["contadorVeiculo"] = 0;
        }
        else 
        {
            $_SESSION["contadorVeiculo"]++;
        }
    }

    public function inicia_session_contadorFinanciamentos()
    {
        $this->inicia_sessao();

        if (!isset($_SESSION["contadorFinanciamento"]))
        {
            $_SESSION["contadorFinanciamento"] = 0;
        }
        else 
        {
            $_SESSION["contadorFinanciamento"]++;
        }
    }
}