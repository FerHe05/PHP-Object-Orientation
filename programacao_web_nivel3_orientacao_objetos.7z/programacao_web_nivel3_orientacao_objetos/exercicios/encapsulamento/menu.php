<?php 
$url_absoluta = "C:\xampp\htdocs\programacao_web_nivel3_orientacao_objetos\exercicios\encapsulamento";

$url = $_SERVER['REQUEST_URI'];

$explode_url = explode("/", $url);

$segmento = 7;

if ($explode_url[$segmento] != "financiadora")
{    
    $url_financiadora = $url_absoluta."financiadora/";
}
else 
{   
    $url_financiadora = "";    
}

if ($explode_url[$segmento] != "veiculo")
{    
    $url_veiculo = $url_absoluta."veiculo/";
}
else 
{   
    $url_veiculo = "";    
}

if ($explode_url[$segmento] != "financiamento")
{    
    $url_financiamento = $url_absoluta."financiamento/";
}
else 
{   
    $url_financiamento = "";    
}
?>

<ul>
    <li>
        <a href="<?php  
            echo $url_financiadora."cadastrar_financiadora.php"; ?>">
            Cadastrar Financiadora
        </a>
    </li>
    <li>
        <a href="<?php  
            echo $url_financiadora."listar_financiadoras.php"; ?>">
            Listar Financiadoras
        </a>
    </li>   
    <li>
        <a href="<?php  
            echo $url_veiculo."cadastrar_veiculo.php"; ?>">
            Cadastrar Veiculo
        </a>
    </li>
    <li>
        <a href="<?php  
            echo $url_veiculo."listar_veiculos.php"; ?>">
            Listar Veiculos
        </a>
    </li>    
    <li>
        <a href="<?php  
            echo $url_financiamento."cadastrar_financiamento.php"; ?>">
            Cadastrar Financiamento
        </a>
    </li>
    <li>
        <a href="<?php  
            echo $url_financiamento."listar_financiamento.php"; ?>">
            Listar Financiamentos
        </a>
    </li>  
    <li><a href="logout.php">Sair</a></li>
</ul>