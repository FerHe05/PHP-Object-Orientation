<?php 

require_once("Sessao.php");

$session = new Sessao();
$session->inicia_sessao(); 

session_destroy();