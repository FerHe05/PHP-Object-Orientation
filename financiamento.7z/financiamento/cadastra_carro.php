<?php


if (isset($_POST["btnEnviar"])){
$carro = $_POST["carro"];
$valor = $_POST["valor"];

}

?>